@echo off
cd /d "%~dp0"
start "" pythonw selector_fotos_escolares.py
if errorlevel 1 pause
