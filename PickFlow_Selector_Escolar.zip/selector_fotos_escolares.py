"""Ramirez Films Selector - selector local de fotos escolares para Windows.

La aplicación nunca borra los originales. Analiza una carpeta y crea dos salidas:
  - Seleccionadas: fotos con mejor calidad técnica.
  - Revision: fotos borrosas, pequeñas, duplicadas o que requieren revisión.

Dependencias: Pillow (obligatoria) y OpenCV (opcional, mejora el análisis de
nitidez y rostros). Ver README_SELECTOR.md.
"""

from __future__ import annotations

import hashlib
import json
import os
import queue
import shutil
import subprocess
import sys
import threading
import urllib.request
import zipfile
from datetime import datetime
from dataclasses import dataclass
from pathlib import Path
from tkinter import END, BOTH, LEFT, RIGHT, X, Y, filedialog, messagebox, ttk
import tkinter as tk

try:
    from PIL import Image, ImageOps, ImageTk
except ImportError:  # pragma: no cover - mensaje visible en la interfaz
    Image = None
    ImageOps = None
    ImageTk = None

try:
    import cv2
    import numpy as np
except ImportError:  # OpenCV es opcional
    cv2 = None
    np = None


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
APP_NAME = "PickFlow"
APP_VERSION = "0.13.0"
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/ivaanhj123/ramirez-films-selector-escolar/main/version.json"


@dataclass
class PhotoResult:
    source: Path
    width: int = 0
    height: int = 0
    sharpness: float = 0.0
    score: float = 0.0
    reason: str = ""
    selected: bool = False
    duplicate: bool = False
    signature: str = ""


def file_hash(path: Path) -> str:
    digest = hashlib.sha1()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def average_hash(image: "Image.Image") -> str:
    """Hash pequeño para detectar copias visualmente iguales o casi iguales."""
    gray = ImageOps.grayscale(image).resize((16, 16))
    values = list(gray.getdata())
    average = sum(values) / len(values)
    return "".join("1" if value >= average else "0" for value in values)


def photo_signature(image: "Image.Image") -> str:
    """Firma visual del área central, donde normalmente está el alumno."""
    width, height = image.size
    crop = image.crop((int(width * 0.16), int(height * 0.04), int(width * 0.84), int(height * 0.96)))
    return average_hash(crop)


def hamming(left: str, right: str) -> int:
    return sum(a != b for a, b in zip(left, right))


def blur_score(image: "Image.Image") -> float:
    """Devuelve una medida aproximada de nitidez (0-100).

    OpenCV ofrece una medida más precisa. Si no está disponible usamos una
    variación de bordes basada únicamente en Pillow.
    """
    if cv2 is not None and np is not None:
        rgb = np.asarray(image.convert("RGB"))
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        variance = float(cv2.Laplacian(gray, cv2.CV_64F).var())
        return min(100.0, variance / 8.0)

    # Fallback sin OpenCV: diferencias medias entre píxeles vecinos.
    small = ImageOps.grayscale(image.copy())
    small.thumbnail((900, 900))
    pixels = list(small.getdata())
    width, height = small.size
    if width < 2 or height < 2:
        return 0.0
    horizontal = sum(abs(pixels[i] - pixels[i + 1]) for i in range(len(pixels) - 1))
    vertical = sum(abs(pixels[i] - pixels[i + width]) for i in range(len(pixels) - width))
    scale = max(1, len(pixels) * 2)
    return min(100.0, (horizontal + vertical) / scale * 1.7)


def closed_eyes_warning(image: "Image.Image") -> bool:
    """Marca una posible foto con ojos cerrados cuando OpenCV puede detectarlos.

    Es una señal de revisión, no una decisión definitiva: perfiles, lentes,
    máscaras o rostros muy pequeños pueden producir falsos positivos.
    """
    if cv2 is None or np is None:
        return False
    try:
        gray = cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2GRAY)
        scale = min(1.0, 1200.0 / max(gray.shape))
        if scale < 1.0:
            gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        cascade_root = cv2.data.haarcascades
        face_detector = cv2.CascadeClassifier(os.path.join(cascade_root, "haarcascade_frontalface_default.xml"))
        eye_detector = cv2.CascadeClassifier(os.path.join(cascade_root, "haarcascade_eye_tree_eyeglasses.xml"))
        faces = face_detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(35, 35))
        if len(faces) == 0:
            return False
        for x, y, width, height in faces[:8]:
            upper_face = gray[y : y + int(height * 0.62), x : x + width]
            eyes = eye_detector.detectMultiScale(upper_face, scaleFactor=1.08, minNeighbors=4, minSize=(8, 8))
            if len(eyes) < 1:
                return True
        return False
    except Exception:
        return False


def analyze_photo(path: Path) -> PhotoResult:
    result = PhotoResult(source=path)
    try:
        with Image.open(path) as original:
            image = ImageOps.exif_transpose(original).convert("RGB")
            result.width, result.height = image.size
            result.sharpness = blur_score(image)
    except Exception as exc:
        result.reason = f"No se pudo leer: {exc}"
        return result

    megapixels = (result.width * result.height) / 1_000_000
    score = min(35.0, megapixels * 4.5)
    score += min(65.0, result.sharpness * 0.65)
    result.score = round(score, 1)

    critical_reasons = []
    warning_reasons = []
    if megapixels < 1.0:
        critical_reasons.append("resolución baja")
    # El umbral anterior era demasiado estricto para retratos escolares.
    if result.sharpness < 7:
        critical_reasons.append("posible desenfoque")
    # Los ojos son una advertencia, no un descarte automático: rostros
    # pequeños, perfiles y lentes provocan falsos positivos con frecuencia.
    if closed_eyes_warning(image):
        warning_reasons.append("revisar ojos")
    result.reason = ", ".join(critical_reasons + warning_reasons)
    result.selected = not critical_reasons
    return result


def select_one_per_series(results: list[PhotoResult], threshold: int = 18) -> None:
    """Conserva una sola ganadora por cada grupo de tomas visualmente parecidas.

    Las fotos se recorren en el orden del nombre de archivo, que coincide con
    el orden de captura de cámaras como Canon IMG_####. Solo se agrupan fotos
    consecutivas para no mezclar alumnos de distintas partes de la sesión.
    """
    if not results:
        return

    groups: list[list[PhotoResult]] = []
    current = [results[0]]
    for result in results[1:]:
        previous = current[-1]
        similar = bool(previous.signature and result.signature and hamming(previous.signature, result.signature) <= threshold)
        if similar:
            current.append(result)
        else:
            groups.append(current)
            current = [result]
    groups.append(current)

    for group in groups:
        if len(group) == 1:
            continue
        winner = max(group, key=lambda item: item.score)
        for item in group:
            item.selected = item is winner
            if item is not winner:
                item.reason = (item.reason + "; misma serie").strip("; ")


class SelectorApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"{APP_NAME} - Selector de Fotos Escolares v{APP_VERSION}")
        self.geometry("900x610")
        self.minsize(760, 500)
        self._icon_image = None
        icon_path = Path(__file__).with_name("pickflow_icon.png")
        if icon_path.exists():
            try:
                self._icon_image = tk.PhotoImage(file=str(icon_path))
                self.iconphoto(True, self._icon_image)
            except tk.TclError:
                self._icon_image = None
        self.folder_var = tk.StringVar()
        self.output_var = tk.StringVar()
        self.subfolders_var = tk.BooleanVar(value=True)
        self.one_per_series_var = tk.BooleanVar(value=True)
        self.status_var = tk.StringVar(value="Selecciona la carpeta de fotos para comenzar.")
        self.results: list[PhotoResult] = []
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self.running = False
        self.preview_images = []
        self.preview_paths: list[Path] = []
        self.preview_cards: dict[str, tk.Frame] = {}
        self.preview_token = 0
        self.cancel_event = threading.Event()
        self.current_folder: Path | None = None
        self.current_phase = "inicio"
        self.projects_file = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "PickFlow" / "projects.json"
        self.current_project_id = ""
        self._build_modern_ui()
        self.after(100, self._poll_events)
        self.after(1400, lambda: self.check_updates(silent=True))

    def _build_ui(self) -> None:
        header = ttk.Frame(self, padding=16)
        header.pack(fill=X)
        ttk.Label(header, text=APP_NAME, font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(header, text=f"Selector inteligente de fotos escolares  •  versión {APP_VERSION}", font=("Segoe UI", 11)).pack(anchor="w")

        paths = ttk.LabelFrame(self, text="Carpetas", padding=12)
        paths.pack(fill=X, padx=16, pady=(0, 10))
        ttk.Label(paths, text="Fotos de entrada:").grid(row=0, column=0, sticky="w", pady=4)
        ttk.Entry(paths, textvariable=self.folder_var).grid(row=0, column=1, sticky="ew", padx=8)
        ttk.Button(paths, text="Elegir...", command=self.choose_folder).grid(row=0, column=2)
        ttk.Label(paths, text="Guardar resultados en:").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Entry(paths, textvariable=self.output_var).grid(row=1, column=1, sticky="ew", padx=8)
        ttk.Button(paths, text="Elegir...", command=self.choose_output).grid(row=1, column=2)
        paths.columnconfigure(1, weight=1)
        ttk.Checkbutton(paths, text="Incluir subcarpetas", variable=self.subfolders_var).grid(row=2, column=1, sticky="w", pady=4)
        ttk.Checkbutton(paths, text="Dejar solo una mejor foto por serie", variable=self.one_per_series_var).grid(row=3, column=1, sticky="w", pady=4)

        actions = ttk.Frame(self, padding=(16, 0, 16, 10))
        actions.pack(fill=X)
        self.start_button = ttk.Button(actions, text="Analizar y separar fotos", command=self.start_analysis)
        self.start_button.pack(side=LEFT)
        ttk.Button(actions, text="Proyectos", command=self.open_projects).pack(side=LEFT, padx=(10, 0))
        ttk.Button(actions, text="Buscar actualizaciones", command=self.check_updates).pack(side=RIGHT)
        self.progress = ttk.Progressbar(actions, mode="determinate")
        self.progress.pack(side=LEFT, fill=X, expand=True, padx=(14, 0))

        summary = ttk.LabelFrame(self, text="Resumen", padding=10)
        summary.pack(fill=X, padx=16, pady=(0, 10))
        self.summary_label = ttk.Label(summary, text="Todavía no hay un análisis.")
        self.summary_label.pack(anchor="w")
        ttk.Label(summary, textvariable=self.status_var, foreground="#555555").pack(anchor="w", pady=(4, 0))

        table_frame = ttk.Frame(self, padding=(16, 0, 16, 16))
        table_frame.pack(fill=BOTH, expand=True)
        columns = ("archivo", "tamaño", "nitidez", "resultado", "motivo")
        self.table = ttk.Treeview(table_frame, columns=columns, show="headings")
        headings = {"archivo": "Archivo", "tamaño": "Tamaño", "nitidez": "Nitidez", "resultado": "Resultado", "motivo": "Motivo"}
        widths = {"archivo": 350, "tamaño": 105, "nitidez": 90, "resultado": 110, "motivo": 220}
        for column in columns:
            self.table.heading(column, text=headings[column])
            self.table.column(column, width=widths[column], anchor="w")
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        self.table.pack(side=LEFT, fill=BOTH, expand=True)
        scroll.pack(side=RIGHT, fill=Y)

    def _build_modern_ui(self) -> None:
        """Interfaz PickFlow con carga y vista previa de miniaturas."""
        bg, panel, text, muted = "#111936", "#192650", "#f3f5ff", "#aab6dc"
        self.configure(bg=bg)
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Pick.TButton", background="#f05092", foreground="white", borderwidth=0, padding=(14, 8))
        style.map("Pick.TButton", background=[("active", "#ff70a8")])
        style.configure("Dark.TButton", background="#263869", foreground=text, borderwidth=0, padding=(10, 7))
        style.map("Dark.TButton", background=[("active", "#38518b")])
        style.configure("Dark.TCheckbutton", background=bg, foreground=text)

        topbar = tk.Frame(self, bg="#0b142e", height=54)
        topbar.pack(fill=X)
        topbar.pack_propagate(False)
        icon_path = Path(__file__).with_name("pickflow_icon.png")
        if icon_path.exists() and Image is not None and ImageTk is not None:
            try:
                icon = Image.open(icon_path).convert("RGBA")
                icon.thumbnail((30, 30), Image.Resampling.LANCZOS)
                self._header_icon = ImageTk.PhotoImage(icon)
                tk.Label(topbar, image=self._header_icon, bg="#0b142e").pack(side=LEFT, padx=(18, 8))
            except Exception:
                pass
        tk.Label(topbar, text=APP_NAME, bg="#0b142e", fg=text, font=("Segoe UI", 14, "bold")).pack(side=LEFT)
        tk.Label(topbar, text="Selector Visual", bg="#213566", fg="#c4d0ff", font=("Segoe UI", 8, "bold"), padx=8, pady=3).pack(side=LEFT, padx=10)
        tk.Label(topbar, text=f"v{APP_VERSION}", bg="#0b142e", fg=muted, font=("Segoe UI", 9)).pack(side=RIGHT, padx=18)

        body = tk.Frame(self, bg=bg)
        body.pack(fill=BOTH, expand=True)
        upload = tk.Frame(body, bg=panel, highlightbackground="#d64b86", highlightthickness=1)
        upload.pack(padx=24, pady=(22, 12), ipadx=30, ipady=18)
        self.upload_card = upload
        tk.Label(upload, text="▧", bg=panel, fg="#ffb84d", font=("Segoe UI Symbol", 28)).pack()
        tk.Label(upload, text="Cargar imagenes", bg=panel, fg=text, font=("Segoe UI", 13, "bold")).pack()
        tk.Label(upload, text="Haz clic para elegir una carpeta de fotos", bg=panel, fg="#c3cbed", font=("Segoe UI", 9)).pack(pady=(3, 7))
        tk.Label(upload, text="● JPG   PNG   WEBP   TIFF", bg=panel, fg="#78e6a2", font=("Segoe UI", 8)).pack()
        for widget in upload.winfo_children():
            widget.bind("<Button-1>", lambda _event: self.choose_folder())

        options = tk.Frame(body, bg=bg)
        options.pack(fill=X, padx=24, pady=(4, 8))
        ttk.Checkbutton(options, text="Incluir subcarpetas", variable=self.subfolders_var, style="Dark.TCheckbutton").pack(side=LEFT)
        ttk.Checkbutton(options, text="Una mejor foto por serie", variable=self.one_per_series_var, style="Dark.TCheckbutton").pack(side=LEFT, padx=20)
        ttk.Button(options, text="Buscar actualizaciones", style="Dark.TButton", command=self.check_updates).pack(side=RIGHT)
        ttk.Button(options, text="Proyectos guardados", style="Dark.TButton", command=self.open_projects).pack(side=RIGHT, padx=(0, 10))

        actions = tk.Frame(body, bg=bg)
        actions.pack(fill=X, padx=24, pady=(0, 8))
        self.start_button = ttk.Button(actions, text="Analizar y separar fotos", style="Pick.TButton", command=self.start_analysis)
        self.start_button.pack(side=LEFT)
        self.back_button = ttk.Button(actions, text="Volver / Cancelar", style="Dark.TButton", command=self.go_back, state="disabled")
        self.back_button.pack(side=LEFT, padx=(10, 0))
        self.progress = ttk.Progressbar(actions, mode="determinate")
        self.progress.pack(side=LEFT, fill=X, expand=True, padx=(14, 0))

        summary = tk.Frame(body, bg=panel)
        summary.pack(fill=X, padx=24, pady=(0, 10))
        self.summary_label = tk.Label(summary, text="Todavia no hay un analisis.", bg=panel, fg=text, font=("Segoe UI", 10, "bold"))
        self.summary_label.pack(anchor="w", padx=12, pady=(8, 0))
        tk.Label(summary, textvariable=self.status_var, bg=panel, fg=muted, font=("Segoe UI", 9)).pack(anchor="w", padx=12, pady=(2, 8))

        preview_box = tk.Frame(body, bg=panel, height=245)
        preview_box.pack_propagate(False)
        preview_box.pack(fill=X, padx=24, pady=(0, 10))
        self.preview_box = preview_box
        preview_header = tk.Frame(preview_box, bg=panel)
        preview_header.pack(fill=X)
        tk.Label(preview_header, text="Vista previa", bg=panel, fg=text, font=("Segoe UI", 11, "bold")).pack(side=LEFT, padx=12, pady=8)
        self.preview_count_label = tk.Label(preview_header, text="Elige una carpeta para ver miniaturas", bg=panel, fg=muted, font=("Segoe UI", 9))
        self.preview_count_label.pack(side=RIGHT, padx=12)
        self.preview_legend = tk.Label(preview_header, text="Verde: seleccionada   Rojo: revision", bg=panel, fg=muted, font=("Segoe UI", 8))
        self.preview_legend.pack(side=RIGHT, padx=(0, 18))
        canvas_frame = tk.Frame(preview_box, bg=panel)
        canvas_frame.pack(fill=BOTH, expand=True, padx=10, pady=(0, 10))
        self.preview_canvas = tk.Canvas(canvas_frame, bg=panel, highlightthickness=0)
        preview_scroll = ttk.Scrollbar(canvas_frame, orient="vertical", command=self.preview_canvas.yview)
        self.preview_inner = tk.Frame(self.preview_canvas, bg=panel)
        self.preview_window = self.preview_canvas.create_window((0, 0), window=self.preview_inner, anchor="nw")
        self.preview_inner.bind("<Configure>", lambda _event: self.preview_canvas.configure(scrollregion=self.preview_canvas.bbox("all")))
        self.preview_canvas.bind("<Configure>", lambda event: self.preview_canvas.itemconfigure(self.preview_window, width=event.width))
        self.preview_canvas.configure(yscrollcommand=preview_scroll.set)
        self.preview_canvas.pack(side=LEFT, fill=BOTH, expand=True)
        preview_scroll.pack(side=RIGHT, fill=Y)

        table_frame = ttk.Frame(body, padding=(0, 0, 0, 16))
        self.table_frame = table_frame
        columns = ("archivo", "tamaño", "nitidez", "resultado", "motivo")
        self.table = ttk.Treeview(table_frame, columns=columns, show="headings")
        headings = {"archivo": "Archivo", "tamaño": "Tamaño", "nitidez": "Nitidez", "resultado": "Resultado", "motivo": "Motivo"}
        widths = {"archivo": 350, "tamaño": 105, "nitidez": 90, "resultado": 110, "motivo": 220}
        for column in columns:
            self.table.heading(column, text=headings[column])
            self.table.column(column, width=widths[column], anchor="w")
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        self.table.pack(side=LEFT, fill=BOTH, expand=True)
        scroll.pack(side=RIGHT, fill=Y)

    def _build_modern_ui(self) -> None:
        """Interfaz PickFlow tipo estudio de seleccion, inspirada en flujos profesionales."""
        bg = "#0b1024"
        panel = "#151e3d"
        panel_alt = "#1b2850"
        text = "#f4f6ff"
        muted = "#a9b6dc"
        accent = "#f05292"
        green = "#38e58b"

        self.configure(bg=bg)
        self.geometry("1120x720")
        self.minsize(900, 620)
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Pick.TButton", background=accent, foreground="white", borderwidth=0, padding=(14, 9), font=("Segoe UI", 9, "bold"))
        style.map("Pick.TButton", background=[("active", "#ff70a8")])
        style.configure("Dark.TButton", background="#263869", foreground=text, borderwidth=0, padding=(11, 8), font=("Segoe UI", 9))
        style.map("Dark.TButton", background=[("active", "#38518b")])
        style.configure("Dark.TCheckbutton", background=bg, foreground=text, font=("Segoe UI", 9))
        style.configure("Pick.Horizontal.TProgressbar", troughcolor="#202c53", background=accent, bordercolor="#202c53", lightcolor=accent, darkcolor=accent)

        shell = tk.Frame(self, bg=bg)
        shell.pack(fill=BOTH, expand=True)

        sidebar = tk.Frame(shell, bg="#0b142e", width=214)
        sidebar.pack(side=LEFT, fill=Y)
        sidebar.pack_propagate(False)
        brand = tk.Frame(sidebar, bg="#0b142e")
        brand.pack(fill=X, padx=18, pady=(20, 24))
        icon_path = Path(__file__).with_name("pickflow_icon.png")
        if icon_path.exists() and Image is not None and ImageTk is not None:
            try:
                icon = Image.open(icon_path).convert("RGBA")
                icon.thumbnail((34, 34), Image.Resampling.LANCZOS)
                self._sidebar_icon = ImageTk.PhotoImage(icon)
                tk.Label(brand, image=self._sidebar_icon, bg="#0b142e").pack(side=LEFT, padx=(0, 9))
            except Exception:
                pass
        tk.Label(brand, text="PickFlow", bg="#0b142e", fg=text, font=("Segoe UI", 16, "bold")).pack(side=LEFT)

        tk.Label(sidebar, text="PROYECTO", bg="#0b142e", fg="#7181b0", font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=20, pady=(0, 8))

        def nav_button(label: str, command, active: bool = False):
            frame = tk.Frame(sidebar, bg="#243664" if active else "#0b142e")
            frame.pack(fill=X, padx=10, pady=3)
            tk.Label(frame, text="●" if active else "○", bg=frame["bg"], fg=accent if active else muted, font=("Segoe UI", 10)).pack(side=LEFT, padx=(10, 8))
            button = tk.Button(frame, text=label, command=command, anchor="w", relief="flat", bd=0, bg=frame["bg"], activebackground="#243664", fg=text, activeforeground=text, font=("Segoe UI", 9, "bold" if active else "normal"), cursor="hand2")
            button.pack(side=LEFT, fill=X, expand=True, pady=7)
            frame.bind("<Button-1>", lambda _event: command())
            return button

        nav_button("Nuevo proyecto", self.go_back, active=True)
        nav_button("Proyectos guardados", self.open_projects)
        nav_button("Buscar actualizaciones", self.check_updates)

        sidebar_spacer = tk.Frame(sidebar, bg="#0b142e")
        sidebar_spacer.pack(fill=BOTH, expand=True)
        tk.Frame(sidebar, bg="#25345f", height=1).pack(fill=X, padx=18, pady=(0, 14))
        tk.Label(sidebar, text="Selector Visual", bg="#0b142e", fg="#d8def5", font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=20)
        tk.Label(sidebar, text=f"Version {APP_VERSION}", bg="#0b142e", fg=muted, font=("Segoe UI", 8)).pack(anchor="w", padx=20, pady=(4, 18))

        content = tk.Frame(shell, bg=bg)
        content.pack(side=LEFT, fill=BOTH, expand=True)

        topbar = tk.Frame(content, bg="#111a37", height=64)
        topbar.pack(fill=X)
        topbar.pack_propagate(False)
        heading = tk.Frame(topbar, bg="#111a37")
        heading.pack(side=LEFT, padx=24)
        tk.Label(heading, text="Selector visual", bg="#111a37", fg=text, font=("Segoe UI", 15, "bold")).pack(side=LEFT)
        tk.Label(heading, text="  /  Nuevo proyecto", bg="#111a37", fg=muted, font=("Segoe UI", 9)).pack(side=LEFT, padx=8)
        tk.Label(topbar, text="LISTO PARA TRABAJAR", bg="#193d42", fg=green, font=("Segoe UI", 8, "bold"), padx=10, pady=5).pack(side=RIGHT, padx=24)

        scroll_host = tk.Frame(content, bg=bg)
        scroll_host.pack(fill=BOTH, expand=True)

        project_header = tk.Frame(scroll_host, bg=bg)
        project_header.pack(fill=X, padx=26, pady=(22, 4))
        tk.Label(project_header, text="Selecciona tus mejores fotos", bg=bg, fg=text, font=("Segoe UI", 20, "bold")).pack(anchor="w")
        tk.Label(project_header, text="Carga una carpeta y PickFlow separara las fotos seleccionadas de las que requieren revision.", bg=bg, fg=muted, font=("Segoe UI", 9)).pack(anchor="w", pady=(5, 0))

        options = tk.Frame(scroll_host, bg=bg)
        options.pack(fill=X, padx=26, pady=(16, 10))
        ttk.Checkbutton(options, text="Incluir subcarpetas", variable=self.subfolders_var, style="Dark.TCheckbutton").pack(side=LEFT)
        ttk.Checkbutton(options, text="Una mejor foto por serie", variable=self.one_per_series_var, style="Dark.TCheckbutton").pack(side=LEFT, padx=22)

        visual_area = tk.Frame(scroll_host, bg=bg)
        visual_area.pack(fill=X, padx=26)

        upload = tk.Frame(visual_area, bg=panel, highlightbackground="#d64b86", highlightcolor="#d64b86", highlightthickness=1, height=190)
        upload.pack(fill=X, pady=(2, 12))
        upload.pack_propagate(False)
        self.upload_card = upload
        tk.Label(upload, text="✦", bg=panel, fg="#ffb84d", font=("Segoe UI Symbol", 30)).pack(pady=(16, 0))
        tk.Label(upload, text="Carga una carpeta de fotos", bg=panel, fg=text, font=("Segoe UI", 14, "bold")).pack()
        tk.Label(upload, text="Haz clic aqui para comenzar o arrastra tus imagenes", bg=panel, fg="#c3cbed", font=("Segoe UI", 9)).pack(pady=(4, 8))
        tk.Label(upload, text="JPG   PNG   WEBP   TIFF", bg=panel, fg=green, font=("Segoe UI", 8, "bold")).pack()
        for widget in upload.winfo_children():
            widget.bind("<Button-1>", lambda _event: self.choose_folder())

        self.preview_box = tk.Frame(visual_area, bg=panel, height=275)
        self.preview_box.pack_propagate(False)
        preview_header = tk.Frame(self.preview_box, bg=panel)
        preview_header.pack(fill=X)
        tk.Label(preview_header, text="Vista previa", bg=panel, fg=text, font=("Segoe UI", 11, "bold")).pack(side=LEFT, padx=14, pady=9)
        self.preview_legend = tk.Label(preview_header, text="Verde: seleccionada   Rojo: revision", bg=panel, fg=muted, font=("Segoe UI", 8))
        self.preview_legend.pack(side=RIGHT, padx=(0, 16))
        self.preview_count_label = tk.Label(preview_header, text="Elige una carpeta para ver miniaturas", bg=panel, fg=muted, font=("Segoe UI", 8))
        self.preview_count_label.pack(side=RIGHT, padx=14)
        canvas_frame = tk.Frame(self.preview_box, bg=panel)
        canvas_frame.pack(fill=BOTH, expand=True, padx=10, pady=(0, 10))
        self.preview_canvas = tk.Canvas(canvas_frame, bg=panel, highlightthickness=0)
        preview_scroll = ttk.Scrollbar(canvas_frame, orient="vertical", command=self.preview_canvas.yview)
        self.preview_inner = tk.Frame(self.preview_canvas, bg=panel)
        self.preview_window = self.preview_canvas.create_window((0, 0), window=self.preview_inner, anchor="nw")
        self.preview_inner.bind("<Configure>", lambda _event: self.preview_canvas.configure(scrollregion=self.preview_canvas.bbox("all")))
        self.preview_canvas.bind("<Configure>", lambda event: self.preview_canvas.itemconfigure(self.preview_window, width=event.width))
        self.preview_canvas.configure(yscrollcommand=preview_scroll.set)
        self.preview_canvas.pack(side=LEFT, fill=BOTH, expand=True)
        preview_scroll.pack(side=RIGHT, fill=Y)

        actions = tk.Frame(scroll_host, bg=bg)
        actions.pack(fill=X, padx=26, pady=(2, 10))
        self.start_button = ttk.Button(actions, text="Analizar y separar fotos", style="Pick.TButton", command=self.start_analysis)
        self.start_button.pack(side=LEFT)
        self.back_button = ttk.Button(actions, text="Volver / Cancelar", style="Dark.TButton", command=self.go_back, state="disabled")
        self.back_button.pack(side=LEFT, padx=(10, 0))
        self.progress = ttk.Progressbar(actions, mode="determinate", style="Pick.Horizontal.TProgressbar")
        self.progress.pack(side=LEFT, fill=X, expand=True, padx=(16, 0), ipady=4)

        summary = tk.Frame(scroll_host, bg=panel_alt)
        summary.pack(fill=X, padx=26, pady=(0, 12))
        self.summary_label = tk.Label(summary, text="Todavia no hay un analisis.", bg=panel_alt, fg=text, font=("Segoe UI", 10, "bold"))
        self.summary_label.pack(anchor="w", padx=14, pady=(9, 0))
        tk.Label(summary, textvariable=self.status_var, bg=panel_alt, fg=muted, font=("Segoe UI", 9)).pack(anchor="w", padx=14, pady=(3, 9))

        self.table_frame = tk.Frame(scroll_host, bg=bg)
        columns = ("archivo", "tama�o", "nitidez", "resultado", "motivo")
        self.table = ttk.Treeview(self.table_frame, columns=columns, show="headings", height=5)
        headings = {"archivo": "Archivo", "tama�o": "Tama�o", "nitidez": "Nitidez", "resultado": "Resultado", "motivo": "Motivo"}
        widths = {"archivo": 300, "tama�o": 100, "nitidez": 90, "resultado": 110, "motivo": 210}
        for column in columns:
            self.table.heading(column, text=headings[column])
            self.table.column(column, width=widths[column], anchor="w")
        scroll = ttk.Scrollbar(self.table_frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        self.table.pack(side=LEFT, fill=BOTH, expand=True)
        scroll.pack(side=RIGHT, fill=Y)

        self.paths = None

    def _read_projects(self) -> list[dict]:
        """Lee el historial local de proyectos sin depender de GitHub."""
        try:
            if not self.projects_file.exists():
                return []
            data = json.loads(self.projects_file.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def _write_projects(self, projects: list[dict]) -> None:
        self.projects_file.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.projects_file.with_suffix(".tmp")
        temporary.write_text(json.dumps(projects, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(self.projects_file)

    def _save_project(self, folder: Path, output: Path, results: list[PhotoResult], one_per_series: bool) -> dict:
        """Guarda o actualiza un proyecto en el historial local."""
        projects = self._read_projects()
        key = f"{folder.resolve()}|{output.resolve()}"
        existing = next((item for item in projects if item.get("key") == key), None)
        now = datetime.now().astimezone().isoformat(timespec="seconds")
        project_id = str(existing.get("id")) if existing else datetime.now().strftime("%Y%m%d%H%M%S%f")
        project_name = str(existing.get("name")) if existing else (folder.name or "Proyecto PickFlow")
        record = {
            "id": project_id,
            "key": key,
            "name": project_name,
            "created_at": existing.get("created_at", now) if existing else now,
            "updated_at": now,
            "input_folder": str(folder),
            "output_folder": str(output),
            "include_subfolders": bool(self.subfolders_var.get()),
            "one_per_series": bool(one_per_series),
            "total": len(results),
            "selected": sum(item.selected for item in results),
            "review": sum(not item.selected for item in results),
            "results": [
                {
                    "source": str(item.source),
                    "width": item.width,
                    "height": item.height,
                    "sharpness": item.sharpness,
                    "score": item.score,
                    "reason": item.reason,
                    "selected": item.selected,
                    "duplicate": item.duplicate,
                    "signature": item.signature,
                }
                for item in results
            ],
        }
        if existing:
            projects[projects.index(existing)] = record
        else:
            projects.insert(0, record)
        self._write_projects(projects)
        self.current_project_id = project_id
        return record

    def _load_project(self, record: dict) -> None:
        """Restaura un proyecto guardado y sus resultados en la interfaz."""
        self.current_project_id = str(record.get("id", ""))
        folder = Path(str(record.get("input_folder", "")))
        output = Path(str(record.get("output_folder", "")))
        self.folder_var.set(str(folder))
        self.output_var.set(str(output))
        self.subfolders_var.set(bool(record.get("include_subfolders", True)))
        self.one_per_series_var.set(bool(record.get("one_per_series", True)))
        restored: list[PhotoResult] = []
        for item in record.get("results", []):
            try:
                restored.append(
                    PhotoResult(
                        source=Path(str(item.get("source", ""))),
                        width=int(item.get("width", 0)),
                        height=int(item.get("height", 0)),
                        sharpness=float(item.get("sharpness", 0.0)),
                        score=float(item.get("score", 0.0)),
                        reason=str(item.get("reason", "")),
                        selected=bool(item.get("selected", False)),
                        duplicate=bool(item.get("duplicate", False)),
                        signature=str(item.get("signature", "")),
                    )
                )
            except (TypeError, ValueError):
                continue
        self.results = restored
        self._show_results()
        selected = sum(item.selected for item in restored)
        name = str(record.get("name", "Proyecto PickFlow"))
        self.summary_label.configure(text=f"{name}: {len(restored)} fotos analizadas | {selected} seleccionadas | {len(restored) - selected} en revision")
        self.status_var.set(f"Proyecto cargado: {name}")
        self.progress.configure(value=len(restored), maximum=max(1, len(restored)))
        if folder.is_dir():
            self._start_preview(folder)

    def open_projects(self) -> None:
        """Muestra el historial local para abrir un proyecto anterior."""
        projects = self._read_projects()
        dialog = tk.Toplevel(self)
        dialog.title("Proyectos guardados")
        dialog.geometry("620x390")
        dialog.minsize(500, 300)
        dialog.transient(self)
        dialog.grab_set()
        dialog.configure(bg="#111936")
        tk.Label(dialog, text="Proyectos guardados", bg="#111936", fg="#f3f5ff", font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=18, pady=(16, 4))
        tk.Label(dialog, text="Cada análisis se guarda automáticamente en este equipo.", bg="#111936", fg="#aab6dc", font=("Segoe UI", 9)).pack(anchor="w", padx=18, pady=(0, 10))
        list_frame = tk.Frame(dialog, bg="#111936")
        list_frame.pack(fill=BOTH, expand=True, padx=18)
        listbox = tk.Listbox(list_frame, bg="#1a2549", fg="#f3f5ff", selectbackground="#f05092", relief="flat", activestyle="none", font=("Segoe UI", 10))
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=listbox.yview)
        listbox.configure(yscrollcommand=scrollbar.set)
        listbox.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill=Y)
        for project in projects:
            updated = str(project.get("updated_at", "")).replace("T", " ")
            listbox.insert(END, f"{project.get('name', 'Proyecto PickFlow')}  |  {updated[:19]}")
        if projects:
            listbox.selection_set(0)
        else:
            listbox.insert(END, "Todavía no hay proyectos guardados")

        buttons = tk.Frame(dialog, bg="#111936")
        buttons.pack(fill=X, padx=18, pady=14)

        def selected_index() -> int | None:
            selection = listbox.curselection()
            if not projects or not selection:
                return None
            return int(selection[0])

        def load_selected() -> None:
            index = selected_index()
            if index is None:
                messagebox.showinfo("Proyectos", "Selecciona un proyecto guardado.", parent=dialog)
                return
            self._load_project(projects[index])
            dialog.destroy()

        def delete_selected() -> None:
            index = selected_index()
            if index is None:
                return
            name = str(projects[index].get("name", "Proyecto PickFlow"))
            if not messagebox.askyesno("Eliminar proyecto", f"¿Eliminar el registro de «{name}»?\n\nLas fotos y carpetas no se borrarán.", parent=dialog):
                return
            projects.pop(index)
            self._write_projects(projects)
            dialog.destroy()
            self.open_projects()

        ttk.Button(buttons, text="Abrir proyecto", style="Pick.TButton", command=load_selected).pack(side=LEFT)
        ttk.Button(buttons, text="Eliminar registro", style="Dark.TButton", command=delete_selected).pack(side=LEFT, padx=8)
        ttk.Button(buttons, text="Cerrar", style="Dark.TButton", command=dialog.destroy).pack(side=RIGHT)

    def choose_folder(self) -> None:
        selected = filedialog.askdirectory(title="Elige la carpeta con fotos escolares")
        if selected:
            self.folder_var.set(selected)
            self._start_preview(Path(selected))

    def _start_preview(self, folder: Path) -> None:
        if Image is None:
            return
        self.current_folder = folder
        self.preview_token += 1
        token = self.preview_token
        self.upload_card.pack_forget()
        self.preview_box.pack_forget()
        self.preview_box.pack(fill=X, padx=24, pady=(22, 10))
        for widget in self.preview_inner.winfo_children():
            widget.destroy()
        self.preview_images.clear()
        self.preview_paths.clear()
        self.preview_cards.clear()
        self.preview_count_label.configure(text="Cargando miniaturas...")
        threading.Thread(target=self._preview_worker, args=(folder, token), daemon=True).start()

    def _preview_worker(self, folder: Path, token: int) -> None:
        try:
            iterator = folder.rglob("*") if self.subfolders_var.get() else folder.glob("*")
            files = sorted((p for p in iterator if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS), key=lambda p: str(p).lower())
            shown = 0
            for path in files[:120]:
                try:
                    with Image.open(path) as original:
                        image = ImageOps.exif_transpose(original).convert("RGB")
                        image.thumbnail((118, 84), Image.Resampling.LANCZOS)
                        self.events.put(("preview", (token, path, image.copy())))
                        shown += 1
                except Exception:
                    continue
            self.events.put(("preview_done", (token, shown, len(files))))
        except Exception as exc:
            self.events.put(("preview_error", (token, str(exc))))

    def _add_thumbnail(self, path: Path, image: "Image.Image") -> None:
        if ImageTk is None:
            return
        photo = ImageTk.PhotoImage(image)
        self.preview_images.append(photo)
        self.preview_paths.append(path)
        index = len(self.preview_images) - 1
        card = tk.Frame(self.preview_inner, bg="#253663", padx=4, pady=4, highlightbackground="#40527e", highlightcolor="#40527e", highlightthickness=1)
        card.grid(row=index // 6, column=index % 6, padx=5, pady=5, sticky="n")
        self.preview_cards[str(path.resolve())] = card
        label = tk.Label(card, image=photo, bg="#253663")
        label.pack()
        tk.Label(card, text=path.name[:20], bg="#253663", fg="#e8ecff", font=("Segoe UI", 7), width=18).pack(pady=(3, 0))
        for result in self.results:
            if result.source.resolve() == path.resolve():
                color = "#38e58b" if result.selected else "#f05272"
                card.configure(highlightbackground=color, highlightcolor=color, highlightthickness=3)
                break

    def choose_output(self) -> None:
        selected = filedialog.askdirectory(title="Elige dónde guardar el resultado")
        if selected:
            self.output_var.set(selected)

    def go_back(self) -> None:
        """Cancela el trabajo actual y vuelve a la pantalla de carga."""
        if self.running:
            self.cancel_event.set()
            self.status_var.set("Cancelando... espera un momento.")
            self.back_button.configure(state="disabled")
            return
        self.preview_token += 1
        self.current_phase = "inicio"
        self.current_folder = None
        self.folder_var.set("")
        self.output_var.set("")
        self.results = []
        self.preview_images.clear()
        self.preview_paths.clear()
        self.preview_cards.clear()
        for widget in self.preview_inner.winfo_children():
            widget.destroy()
        for item in self.table.get_children():
            self.table.delete(item)
        self.preview_box.pack_forget()
        self.upload_card.pack(padx=24, pady=(22, 12), ipadx=30, ipady=18)
        self.summary_label.configure(text="Todavia no hay un analisis.")
        self.status_var.set("Selecciona la carpeta de fotos para comenzar.")
        self.progress.configure(value=0, maximum=1)
        self.start_button.configure(state="normal")
        self.back_button.configure(state="disabled")

    @staticmethod
    def _version_tuple(value: str) -> tuple[int, ...]:
        numbers = []
        for part in str(value).strip().lstrip("v").split("."):
            try:
                numbers.append(int(part))
            except ValueError:
                numbers.append(0)
        return tuple(numbers or [0])

    def check_updates(self, silent: bool = False) -> None:
        """Comprueba y aplica una actualización publicada en GitHub."""
        try:
            request = urllib.request.Request(
                UPDATE_MANIFEST_URL,
                headers={"User-Agent": "RamirezFilmsSelector/" + APP_VERSION},
            )
            with urllib.request.urlopen(request, timeout=8) as response:
                manifest = json.loads(response.read().decode("utf-8"))
            latest = str(manifest.get("version", APP_VERSION))
            if self._version_tuple(latest) <= self._version_tuple(APP_VERSION):
                if not silent:
                    messagebox.showinfo("Actualizaciones", f"Ya tienes la versión más reciente ({APP_VERSION}).")
                return
            download_url = manifest.get("download_url")
            notes = manifest.get("notes", "Hay una nueva versión disponible.")
            if not download_url:
                raise ValueError("La actualización no tiene una dirección de descarga.")
            if messagebox.askyesno("Nueva actualización", f"Versión {latest}\n\n{notes}\n\n¿Descargar e instalar ahora?"):
                self._download_and_apply_update(str(download_url), latest)
        except Exception as exc:
            if not silent:
                messagebox.showwarning("Actualizaciones", f"No se pudo comprobar ahora.\n\n{exc}")

    def _download_and_apply_update(self, download_url: str, latest: str) -> None:
        """Descarga un ZIP de GitHub, reemplaza los archivos y reinicia."""
        app_dir = Path(__file__).resolve().parent
        zip_path = app_dir / ".selector_update.zip"
        extract_dir = app_dir / ".selector_update_extracted"
        try:
            self.status_var.set(f"Descargando actualización {latest}...")
            request = urllib.request.Request(download_url, headers={"User-Agent": "RamirezFilmsSelector/" + APP_VERSION})
            with urllib.request.urlopen(request, timeout=60) as response, zip_path.open("wb") as target:
                shutil.copyfileobj(response, target)
            if extract_dir.exists():
                shutil.rmtree(extract_dir)
            extract_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(zip_path) as archive:
                archive.extractall(extract_dir)
            source_dir = extract_dir
            nested = list(extract_dir.iterdir())
            if len(nested) == 1 and nested[0].is_dir():
                source_dir = nested[0]
            for item in source_dir.iterdir():
                if item.name.startswith("."):
                    continue
                destination = app_dir / item.name
                if item.is_dir():
                    shutil.copytree(item, destination, dirs_exist_ok=True)
                else:
                    shutil.copy2(item, destination)
            zip_path.unlink(missing_ok=True)
            shutil.rmtree(extract_dir, ignore_errors=True)
            messagebox.showinfo("Actualización instalada", "La aplicación se actualizará y se abrirá de nuevo.")
            launcher = Path(sys.executable)
            if launcher.name.lower() == "python.exe":
                pythonw = launcher.with_name("pythonw.exe")
                if pythonw.exists():
                    launcher = pythonw
            subprocess.Popen([str(launcher), str(Path(__file__).resolve())], cwd=str(app_dir))
            self.destroy()
        except Exception:
            zip_path.unlink(missing_ok=True)
            shutil.rmtree(extract_dir, ignore_errors=True)
            raise

    def start_analysis(self) -> None:
        if self.running:
            return
        if Image is None:
            messagebox.showerror("Falta Pillow", "Instala Pillow con: python -m pip install Pillow")
            return
        folder = Path(self.folder_var.get()).expanduser()
        if not folder.is_dir():
            messagebox.showwarning("Carpeta no válida", "Selecciona una carpeta de fotos válida.")
            return
        self.cancel_event.clear()
        self.current_folder = folder
        self.current_phase = "analizando"
        self.running = True
        self.start_button.configure(state="disabled")
        self.back_button.configure(state="normal")
        self.progress.configure(value=0, maximum=1)
        self.status_var.set("Buscando fotos...")
        threading.Thread(target=self._worker, args=(folder, self.one_per_series_var.get()), daemon=True).start()

    def _worker(self, folder: Path, one_per_series: bool) -> None:
        try:
            iterator = folder.rglob("*") if self.subfolders_var.get() else folder.glob("*")
            files = sorted((p for p in iterator if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS and output not in p.parents), key=lambda p: str(p).lower())
            self.events.put(("start", len(files)))
            results: list[PhotoResult] = []
            exact_hashes: dict[str, Path] = {}
            visual_hashes: list[tuple[str, Path]] = []
            for index, path in enumerate(files, 1):
                if self.cancel_event.is_set():
                    self.events.put(("cancelled", None))
                    return
                result = analyze_photo(path)
                try:
                    raw_hash = file_hash(path)
                    if raw_hash in exact_hashes:
                        result.duplicate = True
                        result.selected = False
                        result.reason = "duplicada exacta"
                    else:
                        exact_hashes[raw_hash] = path
                        with Image.open(path) as img:
                            visual = photo_signature(ImageOps.exif_transpose(img).convert("RGB"))
                        result.signature = visual
                        if any(hamming(visual, old_hash) <= 4 for old_hash, _ in visual_hashes):
                            # No se descarta por similitud; solo se marca para revisión.
                            result.reason = (result.reason + "; posible repetida").strip("; ")
                        visual_hashes.append((visual, path))
                except Exception:
                    pass
                results.append(result)
                self.events.put(("progress", (index, len(files), result)))

            if one_per_series:
                select_one_per_series(results)

            self.events.put(("analysis_done", (folder, results, one_per_series)))
        except Exception as exc:
            self.events.put(("error", str(exc)))

    def _save_worker(self, folder: Path, output: Path, results: list[PhotoResult], one_per_series: bool) -> None:
        try:
            selected_dir = output / "Seleccionadas"
            review_dir = output / "Revision"
            selected_dir.mkdir(parents=True, exist_ok=True)
            review_dir.mkdir(parents=True, exist_ok=True)
            total = max(1, len(results))
            for index, result in enumerate(results, 1):
                if self.cancel_event.is_set():
                    self.events.put(("cancelled", None))
                    return
                destination_root = selected_dir if result.selected else review_dir
                relative = result.source.relative_to(folder) if folder in result.source.parents else Path(result.source.name)
                destination = destination_root / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(result.source, destination)
                self.events.put(("save_progress", (index, total, result.source.name)))
            project = self._save_project(folder, output, results, one_per_series)
            self.events.put(("done", (results, project)))
        except Exception as exc:
            self.events.put(("error", str(exc)))

    def _handle_analysis_done(self, folder: Path, results: list[PhotoResult], one_per_series: bool) -> None:
        """Muestra resultados y pide la carpeta de salida solo al terminar el analisis."""
        self.results = results
        self.current_phase = "elegir_salida"
        self._show_results()
        self._apply_preview_colors()
        selected = sum(item.selected for item in results)
        self.summary_label.configure(text=f"Listo: {len(results)} fotos analizadas | {selected} seleccionadas | {len(results) - selected} en revision")
        self.status_var.set("Analisis terminado. Elige donde guardar las fotos.")
        output_text = filedialog.askdirectory(title="Elige la carpeta donde guardar el resultado", initialdir=str(folder.parent))
        if not output_text:
            self.running = False
            self.current_phase = "resultados"
            self.status_var.set("Analisis listo. No se guardaron archivos.")
            self.start_button.configure(state="normal")
            self.back_button.configure(state="normal")
            return
        output = Path(output_text)
        self.output_var.set(str(output))
        self.current_phase = "guardando"
        self.progress.configure(value=0, maximum=max(1, len(results)))
        self.status_var.set("Guardando resultados...")
        threading.Thread(target=self._save_worker, args=(folder, output, results, one_per_series), daemon=True).start()

    def _poll_events(self) -> None:
        try:
            while True:
                event, payload = self.events.get_nowait()
                if event == "start":
                    self.progress.configure(maximum=max(1, int(payload)))
                    self.status_var.set(f"Analizando {payload} fotos...")
                elif event == "progress":
                    index, total, result = payload
                    self.progress.configure(value=index)
                    self.status_var.set(f"Analizando {index} de {total}: {result.source.name}")
                elif event == "preview":
                    token, path, image = payload
                    if token == self.preview_token:
                        self._add_thumbnail(path, image)
                elif event == "preview_done":
                    token, shown, total = payload
                    if token == self.preview_token:
                        suffix = "" if total <= shown else " (se muestran las primeras 120)"
                        self.preview_count_label.configure(text=f"{total} imagenes encontradas{suffix}")
                elif event == "preview_error":
                    token, _error = payload
                    if token == self.preview_token:
                        self.preview_count_label.configure(text="No se pudieron cargar las miniaturas")
                elif event == "analysis_done":
                    folder, results, one_per_series = payload
                    self._handle_analysis_done(folder, results, one_per_series)
                elif event == "save_progress":
                    index, total, filename = payload
                    self.progress.configure(value=index, maximum=max(1, total))
                    self.status_var.set(f"Guardando {index} de {total}: {filename}")
                elif event == "cancelled":
                    self.running = False
                    self.current_phase = "inicio"
                    self.go_back()
                elif event == "done":
                    if isinstance(payload, tuple) and len(payload) == 2:
                        self.results, project = payload
                    else:
                        self.results, project = payload, None
                    self._show_results()
                    self._apply_preview_colors()
                    selected = sum(item.selected for item in self.results)
                    self.summary_label.configure(text=f"Listo: {len(self.results)} fotos analizadas | {selected} seleccionadas | {len(self.results) - selected} en revisión")
                    self.status_var.set("Terminado. Revisa las carpetas Seleccionadas y Revision.")
                    self.running = False
                    self.current_phase = "resultados"
                    self.start_button.configure(state="normal")
                    self.back_button.configure(state="normal")
                elif event == "error":
                    messagebox.showerror("Error", payload)
                    self.status_var.set("Ocurrió un error durante el análisis.")
                    self.running = False
                    self.start_button.configure(state="normal")
                    self.back_button.configure(state="normal")
        except queue.Empty:
            pass
        self.after(100, self._poll_events)

    def _show_results(self) -> None:
        for item in self.table.get_children():
            self.table.delete(item)
        for result in self.results:
            outcome = "Seleccionada" if result.selected else "Revisión"
            self.table.insert("", END, values=(result.source.name, f"{result.width} × {result.height}", f"{result.sharpness:.1f}", outcome, result.reason or "calidad aceptable"))

    def _apply_preview_colors(self) -> None:
        """Marca las miniaturas visibles con un resplandor verde o rojo."""
        for result in self.results:
            card = self.preview_cards.get(str(result.source.resolve()))
            if card is None:
                continue
            color = "#38e58b" if result.selected else "#f05272"
            card.configure(highlightbackground=color, highlightcolor=color, highlightthickness=3)


if __name__ == "__main__":
    app = SelectorApp()
    app.mainloop()
