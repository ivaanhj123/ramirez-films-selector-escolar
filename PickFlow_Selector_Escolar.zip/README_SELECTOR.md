# PickFlow - Selector de Fotos Escolares

## Instalación de Windows

Ejecuta `PickFlow_Setup_0.16.0.exe`. El instalador coloca PickFlow en **Archivos de programa**, crea accesos directos en el escritorio y en el menú Inicio, e incluye el desinstalador. El icono PF queda integrado en la aplicación y en sus accesos.

La instalación y las actualizaciones no eliminan los proyectos guardados. PickFlow los conserva en `%LOCALAPPDATA%\PickFlow\projects.json`. El desinstalador tampoco borra esa carpeta ni las carpetas donde guardaste tus fotos.

Primer prototipo para Windows. El programa analiza fotos localmente y copia el resultado a dos carpetas, sin borrar los originales:

- `Seleccionadas`: fotos con resolución y nitidez aceptables.
- `Revision`: fotos con posible desenfoque, resolución baja, duplicados o errores de lectura.

Las detecciones de ojos se muestran como aviso, pero no descartan por sí solas una foto: en sesiones escolares los rostros pueden ser pequeños, estar de perfil o usar lentes.

Por defecto está activa la opción **Dejar solo una mejor foto por serie**. La aplicación agrupa tomas consecutivas visualmente parecidas y conserva la de mayor puntuación en `Seleccionadas`; las demás quedan en `Revision`. Puedes desactivar esa casilla si quieres conservar varias fotos buenas.

## Cómo probarlo

1. Instala Python 3.11 o posterior para Windows.
2. Abre PowerShell en esta carpeta.
3. Ejecuta:

```powershell
python -m pip install -r requirements_selector.txt
python selector_fotos_escolares.py
```

4. Pulsa **Analizar y separar fotos**.
5. Al terminar el análisis, elige la carpeta donde guardar el resultado.
6. Usa el menú **Archivo**, **Ajustes** y **Ayuda** para administrar proyectos, preferencias e instrucciones.

La app incluye subcarpetas por defecto y conserva la estructura original dentro del resultado. La versión 0.16 incorpora un asistente de IA local: combina nitidez, iluminación, rostros, ojos y encuadre para elegir mejor dentro de cada serie, sin subir fotografías a internet.

## Actualizaciones automáticas

La aplicación revisa la versión automáticamente al abrirse y también incluye el botón **Buscar actualizaciones**. En la versión instalada descarga el nuevo instalador, cierra PickFlow, actualiza los archivos y vuelve a abrirlo. En modo de desarrollo con Python conserva el respaldo de actualización por ZIP.

El archivo `version.json` usa este formato:

```json
{
  "version": "0.16.0",
  "download_url": "https://github.com/ivaanhj123/ramirez-films-selector-escolar/raw/refs/heads/main/PickFlow_Selector_Escolar.zip",
  "installer_url": "https://github.com/ivaanhj123/ramirez-films-selector-escolar/releases/latest/download/PickFlow_Setup_0.16.0.exe",
  "notes": "IA local para puntuar nitidez, ojos, iluminacion y encuadre."
}
```

